//
//  ViewController.swift
//  NoteBook
//
//  Created by Vihan Chandiramani on 24/7/18.
//  Copyright © 2018 Vihan Chandiramani. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    var lastPoint = CGPoint.zero
    var swiped = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        swiped = false
        
        if let touch = touches.first {
            lastPoint = touch.location(in: self.view) /* Assign the point touched to
                                                         the variable lastPoint*/
        }
    }
    
    func drawLines(fromPoint:CGPoint, toPoint:CGPoint) {
        UIGraphicsBeginImageContext(self.view.frame.size)
        imageView.image?.draw(in: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height))
        var context = UIGraphicsGetCurrentContext()
        
        context?.move(to: CGPoint(x: fromPoint.x, y: fromPoint.y))
        context?.addLine(to: CGPoint(x: toPoint.x, y: toPoint.y))
        
        context?.setBlendMode(CGBlendMode.normal)
        context?.setLineCap(CGLineCap.round)
        context?.setLineWidth(globalVariables.width)
        context?.setStrokeColor(UIColor(displayP3Red: globalVariables.red, green: globalVariables.green, blue: globalVariables.blue, alpha: 1.0).cgColor)
        
        context?.strokePath()
        
        imageView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        swiped = true
        
        if let touch = touches.first {
            var currentPoint = touch.location(in: self.view)
            drawLines(fromPoint: lastPoint, toPoint: currentPoint)
            lastPoint = currentPoint
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !swiped {
            drawLines(fromPoint: lastPoint, toPoint: lastPoint)
        }
    }
    
    @IBAction func lineWidth(_ sender: UISlider) {
        globalVariables.width = CGFloat(sender.value)
    }
    
    @IBAction func erase(_ sender: Any) {
        globalVariables.red = 1.0
        globalVariables.blue = 1.0
        globalVariables.green = 1.0
    }
    
    @IBAction func changeColour(_ sender: Any) {
        performSegue(withIdentifier: "colour", sender: self)
    }
    
    @IBAction func `return`(_ sender: Any) {
        performSegue(withIdentifier: "goBack", sender: self)
    }
}


