//
//  GlobalVariables.swift
//  NoteBook
//
//  Created by Vihan Chandiramani on 10/8/18.
//  Copyright © 2018 Vihan Chandiramani. All rights reserved.
//

import Foundation
import UIKit

struct globalVariables {
    
    static var lineColour: CGColor = UIColor.black.cgColor
    
    static var red: CGFloat = 0.0
    
    static var green: CGFloat = 0.0
    
    static var blue: CGFloat = 0.0
    
    static var width: CGFloat = 5.0
    
}
