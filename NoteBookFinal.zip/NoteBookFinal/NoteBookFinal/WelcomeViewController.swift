//
//  WelcomeViewController.swift
//  NoteBook
//
//  Created by Vihan Chandiramani on 30/7/18.
//  Copyright © 2018 Vihan Chandiramani. All rights reserved.
//

import UIKit

class WelcomeViewController: UIViewController {
    
    @IBAction func newNote(_ sender: Any) {
        performSegue(withIdentifier: "newNote", sender: self)
    }
 
    @IBAction func contentsPage(_ sender: Any) {
        performSegue(withIdentifier: "contentsPage", sender: self)
    }
    
}

