//
//  ContentsViewController.swift
//  NoteBook
//
//  Created by Vihan Chandiramani on 13/8/18.
//  Copyright © 2018 Vihan Chandiramani. All rights reserved.
//

import UIKit

class ContentsViewController: UIViewController {
    
    @IBAction func returnToHomeScreen(_ sender: Any) {
        performSegue(withIdentifier: "return", sender: self)
    }
    
    @IBAction func newNote1(_ sender: Any) {
        performSegue(withIdentifier: "newNote1", sender: self)
    }
    
}
