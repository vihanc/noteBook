//
//  ColourViewController.swift
//  NoteBookFinal
//
//  Created by Vihan Chandiramani on 1/11/18.
//  Copyright © 2018 Vihan Chandiramani. All rights reserved.
//

import UIKit

class ColourViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        popUpView.layer.cornerRadius = 10
        popUpView.layer.masksToBounds = true
        imageView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1.0)
    }
    
    @IBAction func red(_ sender: UISlider) {
        globalVariables.red = CGFloat(sender.value)
        previewColour(red: globalVariables.red, green: globalVariables.green, blue: globalVariables.blue)
    }
    
    @IBAction func green(_ sender: UISlider) {
        globalVariables.green = CGFloat(sender.value)
        previewColour(red: globalVariables.red, green: globalVariables.green, blue: globalVariables.blue)
    }
    
    @IBAction func blue(_ sender: UISlider) {
        globalVariables.blue = CGFloat(sender.value)
        previewColour(red: globalVariables.red, green: globalVariables.green, blue: globalVariables.blue)
    }
    
    @IBAction func done(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var popUpView: UIView!
    @IBOutlet weak var imageView: UIImageView!
    
    @IBAction func black(_ sender: Any) {
        globalVariables.red = 0
        globalVariables.green = 0
        globalVariables.blue = 0
        previewColour(red: globalVariables.red, green: globalVariables.green, blue: globalVariables.blue)
    }
    
    func previewColour(red: CGFloat, green: CGFloat, blue: CGFloat) {
        imageView.backgroundColor = UIColor(red: red, green: green, blue: blue, alpha: 1.0)
    }
    
    
    
    
}
